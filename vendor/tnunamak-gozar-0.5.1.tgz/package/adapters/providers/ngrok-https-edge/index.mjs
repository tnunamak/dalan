// ngrok HTTPS edge, attached kind: a listener opened through the ngrok SDK while the host process runs.
//
// The SDK is an optional dependency, injected as a module (`loadSdk`). The auth token and the reserved
// domain are per-user setup values. The token is stored through a `provide-secret` action in Gozar's private
// store; the reserved domain is not a secret, so it is a `provide-value` action kept as plain configuration. Gozar answers `ctx.configuration(null)` with the values this adapter's completed actions supplied,
// keyed by action id: `{auth, 'reserved-domain'}`. The token never enters facts, plans, receipts, errors or
// output: every failure below uses a fixed message and never the SDK's own text.
import { recipeAdapter, effectError } from '../../../packages/gozar-node/adapter-runtime.mjs';
import { supportedPlatform } from '../../../packages/gozar-node/platform.mjs';
import { createHash } from 'node:crypto';
import {createListenerLifecycle} from '../_shared/sdk-lifecycle.mjs';
import {listenerSdk} from '../_shared/listener-effects.mjs';

import { domainPattern, ngrokSetup } from './setup.mjs';
const decode = bytes => new TextDecoder().decode(bytes).trim();
const sha = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');

// The setup values, trimmed as the setup action validated them; each is null until it is set.
const read = config => {
  const auth = typeof config?.auth === 'string' ? config.auth.trim() : '';
  const domain = typeof config?.['reserved-domain'] === 'string' ? config['reserved-domain'].trim() : '';
  return { authToken: auth.length > 0 ? auth : null, reservedDomain: domainPattern.test(domain) ? domain : null };
};
const settings = config => { const values = read(config); return values.authToken && values.reservedDomain ? values : null; };

export function createNgrokAdapter({ loadSdk = () => import('@ngrok/ngrok'), fetchManagement = fetch } = {}) {
  const lifecycle=createListenerLifecycle({adapterId:'ngrok-https-edge'});
  const keyFor = domain => `ngrok-https-edge:${domain}`;

  return recipeAdapter({
    definition: new URL('./definition.json', import.meta.url),
    extend: ({ base, definition, platformOf, unsupported }) => {
      const action = (id, label, secretLabel) => {
        const body = { id, kind: 'provide-secret', label, secretLabel,help:'Use an agent authtoken, not an API key. Saving it checks local syntax only; presence does not establish provider acceptance.', obtainUrl: 'https://dashboard.ngrok.com/get-started/your-authtoken', disclosure: definition.disclosure };
        return { ...body, digest: sha(body) };
      };
      const authAction = action('auth', 'Provide your ngrok agent authtoken', 'ngrok agent authtoken');
      const domainAction = (() => {
        const body = { id: 'reserved-domain', kind: 'provide-value', label: 'Provide your assigned development or reserved domain', valueLabel: 'Assigned development or reserved domain',
          help:'Copy the assigned development domain from your account; it is valid on Free. The reserved ngrok-branded domains are distinct from bring-your-own domains; use either only if your account already permits it.',obtainUrl: 'https://dashboard.ngrok.com/domains', valuePlaceholder: 'example.ngrok.app', valueFormat: 'domain', required: true, disclosure: definition.disclosure };
        return { ...body, digest: sha(body) };
      })();
      const installAction = (() => {
        const body = { id: 'install-sdk', kind: 'instructions', label: 'Install the ngrok SDK', disclosure: definition.disclosure,
          instructions: 'Install the optional peer runtime in your app: npm install @ngrok/ngrok@1.7.0, then ask the catalog again.' };
        return { ...body, digest: sha(body) };
      })();

      const sdkAvailable = ctx => listenerSdk(ctx, loadSdk).then(
        module => typeof (module?.forward ?? module?.default?.forward) === 'function', () => false);
      const domainError = message => Object.assign(effectError('setup_required', message), { nextAction: structuredClone(domainAction) });
      const refusal = code => ({
        '313': 'Use the assigned development domain or choose an account plan that permits custom subdomains.',
        '314': 'Use the assigned development domain or choose an account plan that permits custom hostnames.',
        '316': 'The agent credential policy does not allow this hostname. Choose a permitted hostname or ask the account administrator for a narrowly scoped credential.',
        '319': 'This hostname needs a domain reservation in the agent credential’s account.',
        '320': 'This hostname belongs to another ngrok account. Check that the agent credential and hostname are from the same account.',
        '334': 'Another endpoint already uses this hostname. Choose an unused hostname or ask the endpoint owner to release it.',
        '6025': 'Another endpoint already uses this hostname. Choose an unused hostname or ask the endpoint owner to release it.',
      })[code];

      const { entry, ...setup } = ngrokSetup({ definition, authAction, domainAction, sdkAvailable, fetchManagement });
      return {
        ...setup,
        async detect(ctx) {
          const os = platformOf(ctx);
          if (!supportedPlatform(os)) return { state: 'unsupported', facts: { platform: os, sdk: false, authSet: false, domainSet: false, configured: false, setupNeeded: false } };
          const sdk = await sdkAvailable(ctx);
          const values = read(await ctx.configuration(null).catch(() => null));
          const configured = values.authToken !== null && values.reservedDomain !== null, ready = sdk && configured;
          return { state: ready ? 'ready' : 'action-required',
            facts: { platform: os, sdk, authSet: values.authToken !== null, domainSet: values.reservedDomain !== null, configured, setupNeeded: !ready } };
        },

        setupActions: facts => (!facts?.setupNeeded ? [] : [...(facts.sdk ? [] : [installAction]), ...(facts.authSet ? [] : [authAction]), ...(facts.domainSet ? [] : [domainAction]), entry]),

        async setup(ctx, actionId, secretHandle) {
          // The reserved domain is a provide-value action: Gozar checks and keeps it, and asks the adapter nothing.
          if (actionId !== 'auth') throw unsupported(`setup action ${String(actionId).slice(0, 64)}`);
          const next = authAction;
          if (typeof secretHandle !== 'string' || !secretHandle) return { state: 'pending', nextAction: next };
          let valid;
          try {
            valid = await ctx.withSecret(secretHandle, async bytes => bytes.length <= 512 && decode(bytes).length > 0);
          } catch { throw effectError('setup_required', 'The private store did not release the value; run the setup action again'); }
          return valid ? { state: 'complete', nextAction: null } : { state: 'blocked', nextAction: next };
        },

        async plan(ctx, request) {
          if (!supportedPlatform(platformOf(ctx))) throw unsupported('this platform');
          if (request?.usage?.kind !== 'attached') throw unsupported(`the ${request?.usage?.kind} kind`);
          const config = settings(await ctx.configuration(request.configurationRef ?? null).catch(() => null));
          if (!config) throw effectError('setup_required', 'Set up the ngrok agent authtoken and assigned development or reserved domain first');
          const origin = `https://${config.reservedDomain}`;
          if (request.origin && request.origin !== origin) throw effectError('setup_required', 'The requested origin differs from the configured account domain');
          const resourceKey = keyFor(config.reservedDomain);
          const effects = [{ adapterId: definition.id, operation: 'create', kind: 'sdk-listener', target: request.target, origin, configurationRef: request.configurationRef ?? null }];
          return { digest: sha({ resourceKey, effects }), origin, resourceKey, effects,
            readback: { kind: 'attached', origin, target: request.target }, cleanup: { operation: 'close-listener' }, precondition: null };
        },

        async create(ctx, plan) {
          const [effect] = plan?.effects ?? [];
          if (plan?.readback?.kind !== 'attached' || effect?.kind !== 'sdk-listener') throw unsupported('this kind');
          await ctx.assertGeneration();
          if (!Number.isSafeInteger(ctx.generation)) throw effectError('provider_unavailable', 'The context carries no generation');
          const config = settings(await ctx.configuration(effect.configurationRef).catch(() => null));
          if (!config || `https://${config.reservedDomain}` !== effect.origin) throw effectError('setup_required', 'Set up the ngrok agent authtoken and assigned development or reserved domain first');
          const sdk = await listenerSdk(ctx, loadSdk);
          // SDK 1.7.0 exposes this exact lookup for listeners in the current host.
          if (typeof sdk.getListenerByUrl === 'function') {
            let existing;
            try { existing = await sdk.getListenerByUrl(effect.origin); }
            catch { throw effectError('provider_unavailable', 'Could not check the hostname in the ngrok SDK'); }
            if (existing) throw domainError(refusal('334'));
          }
          let rejected;
          const scopedSdk = {
            ...(sdk.getListener ? { getListener: sdk.getListener.bind(sdk) } : {}),
            async forward(options) {
              try { return await (sdk.forward ?? sdk.default.forward)(options); }
              catch (error) {
                const diagnostic = [error?.code, error?.error_code, error?.message].find(value =>
                  typeof value === 'string' && /\bERR_NGROK_\d+\b/.test(value));
                rejected = refusal(diagnostic?.match(/\bERR_NGROK_(\d+)\b/)?.[1]);
                throw error;
              }
            },
          };
          try {
            return await lifecycle.open(ctx, plan, { sdk: scopedSdk, credentialAction: authAction,
              options: { addr: effect.target, authtoken: config.authToken, domain: config.reservedDomain } });
          } catch (error) {
            if (!rejected) throw error;
            const safe = domainError(rejected);
            safe.cleanupReceipt = error.cleanupReceipt;
            throw safe;
          }
        },

        async observe(ctx, request) {
          const domain = settings(await ctx.configuration(request.configurationRef ?? null).catch(() => null))?.reservedDomain ?? null;
          const resourceKey = domain ? keyFor(domain) : definition.id;
          return lifecycle.observed(resourceKey);
        },

        async remove(ctx, receipt) {
          return lifecycle.remove(ctx,receipt);
        },
      };
    },
  });
}

export default createNgrokAdapter();
