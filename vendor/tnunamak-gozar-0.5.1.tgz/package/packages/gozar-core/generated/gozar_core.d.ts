/* tslint:disable */
/* eslint-disable */
export function step(input_json: string): string;
